# Previsão do tempo em Flutter

Aplicativo híbrido que mostra a previsão do tempo.
Pode usar a localização do GPS ou o nome da cidade informada pelo usuário.
O aplicativo coleta as informações do OpenWeather API.

## Demonstração
![ezgif-7-b9222d1d3f54](https://user-images.githubusercontent.com/7269894/73614383-3e16ec00-45dd-11ea-949f-954de096d8b9.gif)
